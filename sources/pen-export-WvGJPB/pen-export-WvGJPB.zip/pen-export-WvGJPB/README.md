# Text typing thingamy

A Pen created on CodePen.io. Original URL: [https://codepen.io/jackarmley/pen/WvGJPB](https://codepen.io/jackarmley/pen/WvGJPB).

Thanks @shadowmint!